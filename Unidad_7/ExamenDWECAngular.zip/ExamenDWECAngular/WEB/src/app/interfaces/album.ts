export interface Album {
  _id?: string;
  title: string;
  artist: string;
  year: number;
  genre: string;
  coverUrl: string;
}
