class Song {
  constructor(title, duration, rating, albumId, listened) {
    this.title = title;
    this.duration = duration;
    this.rating = rating;
    this.albumId = albumId;
    this.listened = listened;
  }
}
module.exports = Song;
