class Album {
  constructor(title, artist, year, genre, coverUrl) {
    this.title = title;
    this.artist = artist;
    this.year = year;
    this.genre = genre;
    this.coverUrl = coverUrl;
  }
}
module.exports = Album;
