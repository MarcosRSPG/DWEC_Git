export const POKEMON_KEY = "pokemons";
export const STATE_KEY = "estados";
