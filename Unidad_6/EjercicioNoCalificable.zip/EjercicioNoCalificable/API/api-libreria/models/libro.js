// Clase Libro
class Libro {
  constructor(id, titulo, autor, anio) {
    this.id = id;
    this.titulo = titulo;
    this.autor = autor;
    this.anio = anio;
  }
}

module.exports = Libro;
