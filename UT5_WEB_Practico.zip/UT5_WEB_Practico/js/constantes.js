export const USER_PASS = "userpass";
export const NUM_GLOB = "numeroDeGlobos";
export const PUNTUACION = "puntuacion";
