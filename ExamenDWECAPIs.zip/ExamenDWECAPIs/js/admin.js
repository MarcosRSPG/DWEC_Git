import { Facade } from "./ui/Facade.js";

const facade = new Facade();

facade.cargarProductos();
