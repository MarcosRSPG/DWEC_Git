class Product {
  constructor(name, description, price, user) {
    this.name = name;
    this.description = description;
    this.price = price;
    this.user = user;
  }
}

module.exports = Product;
