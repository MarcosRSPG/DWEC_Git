class User {
  constructor(name, password, admin) {
    this.name = name;
    this.password = password;
    this.admin = admin;
  }
}

module.exports = User;
