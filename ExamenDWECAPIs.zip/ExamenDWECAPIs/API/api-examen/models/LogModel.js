class Log {
  constructor(message, level, time) {
    this.message = message;
    this.level = level;
    this.time = time;
  }
}
