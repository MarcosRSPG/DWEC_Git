export const TRENES_KEY = "trenes";
export const SODOR_KNAPFORD = 25;
export const SODOR_VICARSTOWN = 15;
export const KNAPFORD_VICARSTOWN = 10;
export const VICARSTOWN_TIDMOUTH = 12;
